import React from 'react'

const QAPage = () =>{
    return(
        <div>
            QAPage
        </div>
    )
}
export default QAPage